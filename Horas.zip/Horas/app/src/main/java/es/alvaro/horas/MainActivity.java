package es.alvaro.horas;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Date fecha= new Date();
        TextView lblDateShow=findViewById(R.id.LblDateShow);
        String strDateFormat = "dd/MM/YYYY";
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat);
        lblDateShow.setText(objSDF.format(fecha));


        TextView lblTimeShow=findViewById(R.id.LblTimeShow);
        String strDateFormat2 = "hh:mm";
        SimpleDateFormat objSDF2 = new SimpleDateFormat(strDateFormat2);
        lblTimeShow.setText(objSDF2.format(fecha));
    }
}
